﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;

namespace bank_software
{
    public class Account
    {
        public int Account_ID { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Email { get; set; }
        public string Contact_Number { get; set; }
        public DateTime DOB { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public void AddAccount()
        {
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand insert = new OleDbCommand();
            insert.Connection = connection;
            insert.CommandText = "INSERT INTO Accounts (First_Name, Last_Name, Email, Contact_Number, DOB, Username, [Password]) Values (?,?,?,?,?,?,?)";
            insert.Parameters.AddWithValue("Firstname", this.First_Name);
            insert.Parameters.AddWithValue("Lastname", this.Last_Name);
            insert.Parameters.AddWithValue("Email", this.Email);
            insert.Parameters.AddWithValue("Contact_Number", this.Contact_Number);
            insert.Parameters.AddWithValue("DOB", this.DOB);
            insert.Parameters.AddWithValue("Username", this.Username);
            insert.Parameters.AddWithValue("Password", this.Password);
            insert.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Registered Successfully");
        }
        public List<string> GetName()
        {
            List<string> Names = new List<string>();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand select = new OleDbCommand();
            select.Connection = connection;
            select.CommandText = "SELECT First_Name, Last_Name FROM Accounts WHERE Account_ID = ?";
            select.Parameters.AddWithValue("Account_ID", this.Account_ID);
            OleDbDataReader reader = select.ExecuteReader();
            while (reader.Read())
            {
                string fname = "";
                string lname = "";
                fname = (string)reader["First_name"];
                lname = (string)reader["Last_name"];
                Names.Add(fname);
                Names.Add(lname);
                //Account a = new Account();
                //a.Account_ID = (int)reader["Account_ID"];
                //a.First_Name = (string)reader["First_name"];
                //a.Last_Name = (string)reader["Last_name"];
                //a.Email = (string)reader["Email"];
                //a.Contact_Number = (string)reader["Contact_Number"];
                //a.DOB = (DateTime)reader["DOB"];
                //a.Username = (string)reader["Username"];
                //a.Password = (string)reader["Password"];
                //Names.Add(a);
            }
            connection.Close();
            return Names;

        }
        public Account FindAccountID()
        {
            Account a = new Account();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand select = new OleDbCommand();
            select.Connection = connection;
            select.CommandText = "select Account_ID From Accounts where Username=? and [Password]=?";
            select.Parameters.AddWithValue("Username", this.Username);
            select.Parameters.AddWithValue("Password", this.Password);
            OleDbDataReader reader = select.ExecuteReader();
            if (reader.Read())
            {

                a.Account_ID = (int)reader["Account_ID"];
            }
            else
            {
                a = null;
            }
            connection.Close();
            return a;
        }
        public bool AccountLogin()
        {
            bool status;
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "SELECT Count(*) FROM Accounts WHERE Username=? and [Password]=?";
            command.Parameters.AddWithValue("Username", this.Username);
            command.Parameters.AddWithValue("Password", this.Password);

            int i = Convert.ToInt32(command.ExecuteScalar());
            if (i == 0)
            {
                status = false;
            }
            else
            {
                status = true;
            }
            connection.Close();
            return status;
        }
    }
}
