﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bank_software
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

       //redirecting user to Add Expenses page
        private void btnAddExp_Click(object sender, EventArgs e)
        {
            AddExp ob1form;
            ob1form = new AddExp();
            ob1form.Show();
            this.Hide();
        }

       //redirecting user to View Expenses page
        private void btnViewExp_Click(object sender, EventArgs e)
        {
            ViewExp ob2form;
            ob2form = new ViewExp();
            ob2form.Show();
            this.Hide();
        }

        //Logout button
        private void btnLogOut_Click(object sender, EventArgs e)
        {
            //validation to confirm before logging out
            string message = "Are you sure you want to logout?";
            string title = "Logout";
            MessageBoxButtons confirmbutton = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, confirmbutton);
            if (result == DialogResult.Yes)
            {
                Login ob3form;
                ob3form = new Login();
                ob3form.Show();
                this.Hide();
            }
        }

        //redirecting user to Dashboard
        private void btnDashb_Click(object sender, EventArgs e)
        {
            Dashboard ob3form;
            ob3form = new Dashboard();
            ob3form.Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            //for displaying the user's first name and last name upon logging in
            List<string> namelist = new List<string>();
            Account a = new Account();
            a.Account_ID = Global.global_account_ID;
            namelist = a.GetName();
            label7.Text = namelist[0];
            label6.Text = namelist[1];
        }
    }
}
