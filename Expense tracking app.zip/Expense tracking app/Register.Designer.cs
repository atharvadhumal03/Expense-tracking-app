﻿
namespace bank_software
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            this.dateTimeDOB = new System.Windows.Forms.DateTimePicker();
            this.btnregReset = new System.Windows.Forms.Button();
            this.btnregSubmit = new System.Windows.Forms.Button();
            this.txtregPass = new System.Windows.Forms.TextBox();
            this.txtregCreatePass = new System.Windows.Forms.TextBox();
            this.txtregUname = new System.Windows.Forms.TextBox();
            this.txtregEmail = new System.Windows.Forms.TextBox();
            this.txtregLname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtregFname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnLoginPage = new System.Windows.Forms.Button();
            this.pbBack = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimeDOB
            // 
            this.dateTimeDOB.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeDOB.Location = new System.Drawing.Point(151, 308);
            this.dateTimeDOB.Name = "dateTimeDOB";
            this.dateTimeDOB.Size = new System.Drawing.Size(300, 23);
            this.dateTimeDOB.TabIndex = 34;
            // 
            // btnregReset
            // 
            this.btnregReset.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnregReset.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregReset.Location = new System.Drawing.Point(394, 552);
            this.btnregReset.Name = "btnregReset";
            this.btnregReset.Size = new System.Drawing.Size(176, 49);
            this.btnregReset.TabIndex = 33;
            this.btnregReset.Text = "CLEAR";
            this.btnregReset.UseVisualStyleBackColor = false;
            this.btnregReset.Click += new System.EventHandler(this.btnregReset_Click);
            // 
            // btnregSubmit
            // 
            this.btnregSubmit.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnregSubmit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregSubmit.Location = new System.Drawing.Point(212, 552);
            this.btnregSubmit.Name = "btnregSubmit";
            this.btnregSubmit.Size = new System.Drawing.Size(176, 49);
            this.btnregSubmit.TabIndex = 32;
            this.btnregSubmit.Text = "SIGN UP";
            this.btnregSubmit.UseVisualStyleBackColor = false;
            this.btnregSubmit.Click += new System.EventHandler(this.btnregSubmit_Click);
            // 
            // txtregPass
            // 
            this.txtregPass.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtregPass.Location = new System.Drawing.Point(241, 469);
            this.txtregPass.Multiline = true;
            this.txtregPass.Name = "txtregPass";
            this.txtregPass.Size = new System.Drawing.Size(320, 43);
            this.txtregPass.TabIndex = 31;
            // 
            // txtregCreatePass
            // 
            this.txtregCreatePass.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtregCreatePass.Location = new System.Drawing.Point(241, 417);
            this.txtregCreatePass.Multiline = true;
            this.txtregCreatePass.Name = "txtregCreatePass";
            this.txtregCreatePass.Size = new System.Drawing.Size(320, 46);
            this.txtregCreatePass.TabIndex = 29;
            // 
            // txtregUname
            // 
            this.txtregUname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtregUname.Location = new System.Drawing.Point(241, 362);
            this.txtregUname.Multiline = true;
            this.txtregUname.Name = "txtregUname";
            this.txtregUname.Size = new System.Drawing.Size(320, 49);
            this.txtregUname.TabIndex = 28;
            // 
            // txtregEmail
            // 
            this.txtregEmail.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtregEmail.Location = new System.Drawing.Point(128, 255);
            this.txtregEmail.Multiline = true;
            this.txtregEmail.Name = "txtregEmail";
            this.txtregEmail.Size = new System.Drawing.Size(228, 34);
            this.txtregEmail.TabIndex = 25;
            // 
            // txtregLname
            // 
            this.txtregLname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtregLname.Location = new System.Drawing.Point(515, 204);
            this.txtregLname.Multiline = true;
            this.txtregLname.Name = "txtregLname";
            this.txtregLname.Size = new System.Drawing.Size(228, 34);
            this.txtregLname.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 211);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "First name:";
            // 
            // txtregFname
            // 
            this.txtregFname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtregFname.Location = new System.Drawing.Point(128, 204);
            this.txtregFname.Multiline = true;
            this.txtregFname.Name = "txtregFname";
            this.txtregFname.Size = new System.Drawing.Size(228, 34);
            this.txtregFname.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 173);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(310, 22);
            this.label1.TabIndex = 18;
            this.label1.Text = "Please fill in the following details:\r\n";
            // 
            // txtContact
            // 
            this.txtContact.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContact.Location = new System.Drawing.Point(515, 255);
            this.txtContact.Multiline = true;
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(228, 33);
            this.txtContact.TabIndex = 36;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(393, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 20);
            this.label3.TabIndex = 38;
            this.label3.Text = "Last name:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(385, 259);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 20);
            this.label10.TabIndex = 39;
            this.label10.Text = "Contact No:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 259);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 20);
            this.label11.TabIndex = 40;
            this.label11.Text = "Email add:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 310);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 20);
            this.label4.TabIndex = 41;
            this.label4.Text = "Date Of Birth:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 378);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(186, 23);
            this.label9.TabIndex = 43;
            this.label9.Text = "Create username:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(209, 617);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(173, 17);
            this.label6.TabIndex = 46;
            this.label6.Text = "Already have an account?";
            // 
            // btnLoginPage
            // 
            this.btnLoginPage.BackColor = System.Drawing.Color.Gainsboro;
            this.btnLoginPage.Location = new System.Drawing.Point(212, 637);
            this.btnLoginPage.Name = "btnLoginPage";
            this.btnLoginPage.Size = new System.Drawing.Size(197, 35);
            this.btnLoginPage.TabIndex = 47;
            this.btnLoginPage.Text = "LOGIN ";
            this.btnLoginPage.UseVisualStyleBackColor = false;
            this.btnLoginPage.Click += new System.EventHandler(this.btnLoginPage_Click);
            // 
            // pbBack
            // 
            this.pbBack.Image = ((System.Drawing.Image)(resources.GetObject("pbBack.Image")));
            this.pbBack.Location = new System.Drawing.Point(12, 12);
            this.pbBack.Name = "pbBack";
            this.pbBack.Size = new System.Drawing.Size(74, 64);
            this.pbBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbBack.TabIndex = 48;
            this.pbBack.TabStop = false;
            this.pbBack.Click += new System.EventHandler(this.pbBack_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 478);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(196, 23);
            this.label7.TabIndex = 50;
            this.label7.Text = "Confirm Password:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 428);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(185, 23);
            this.label8.TabIndex = 51;
            this.label8.Text = "Create Password:";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(334, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(147, 123);
            this.pictureBox4.TabIndex = 52;
            this.pictureBox4.TabStop = false;
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(774, 706);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pbBack);
            this.Controls.Add(this.btnLoginPage);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.dateTimeDOB);
            this.Controls.Add(this.btnregReset);
            this.Controls.Add(this.btnregSubmit);
            this.Controls.Add(this.txtregPass);
            this.Controls.Add(this.txtregCreatePass);
            this.Controls.Add(this.txtregUname);
            this.Controls.Add(this.txtregEmail);
            this.Controls.Add(this.txtregLname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtregFname);
            this.Controls.Add(this.label1);
            this.Name = "Register";
            this.Text = "Register";
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimeDOB;
        private System.Windows.Forms.Button btnregReset;
        private System.Windows.Forms.Button btnregSubmit;
        private System.Windows.Forms.TextBox txtregPass;
        private System.Windows.Forms.TextBox txtregCreatePass;
        private System.Windows.Forms.TextBox txtregUname;
        private System.Windows.Forms.TextBox txtregEmail;
        private System.Windows.Forms.TextBox txtregLname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtregFname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnLoginPage;
        private System.Windows.Forms.PictureBox pbBack;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}