﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bank_software
{
    public partial class ViewExp : Form
    {
        public ViewExp()
        {
            InitializeComponent();
        }
        List<Expenses> exp;

       //loading all expenses made by user
        private void ViewExp_Load(object sender, EventArgs e)
        {
            gpEdit.Visible = false;
            Expenses a = new All();
            a.Account_ID = Global.global_account_ID;
            cbCategory.SelectedItem = "All";
            exp = a.ViewExpense();
            datagridViewExp.DataSource = exp;
            datagridViewExp.Columns[1].Visible = false;
        }

        //redirecting user back to menu
        private void pbBack_Click(object sender, EventArgs e)
        {
            Menu ob1form;
            ob1form = new Menu();
            ob1form.Show();
            this.Hide();
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
           //validation for checking if a month has been selected
            if (cbMonth.SelectedItem == default)
            {
                MessageBox.Show("Please select a month");
            }

            //calling method from All subclass
            else if (cbCategory.SelectedItem.ToString() == "All")
            {
                Expenses a = new MonthlyExp();
                a.Account_ID = Global.global_account_ID;
                a.Month_Name = cbMonth.SelectedItem.ToString();
                exp = a.ViewExpense();
                datagridViewExp.DataSource = exp;
                datagridViewExp.Columns[1].Visible = false;
            }

            //calling method from Home subclass
            else if (cbCategory.SelectedItem.ToString() == "Home")
            {
                Expenses a = new Home();
                a.Account_ID = Global.global_account_ID;
                a.Month_Name = cbMonth.SelectedItem.ToString();
                exp = a.ViewExpense();
                datagridViewExp.DataSource = exp;
                datagridViewExp.Columns[1].Visible = false;
            }

            //calling method from Health subclass
            else if (cbCategory.SelectedItem.ToString() == "Health")
            {
                Expenses a = new Health();
                a.Account_ID = Global.global_account_ID;
                a.Month_Name = cbMonth.SelectedItem.ToString();
                exp = a.ViewExpense();
                datagridViewExp.DataSource = exp;
                datagridViewExp.Columns[1].Visible = false;
            }

            //calling method from Transport subclass
            else if (cbCategory.SelectedItem.ToString() == "Transport")
            {
                Expenses a = new Transport();
                a.Account_ID = Global.global_account_ID;
                a.Month_Name = cbMonth.SelectedItem.ToString();
                exp = a.ViewExpense();
                datagridViewExp.DataSource = exp;
                datagridViewExp.Columns[1].Visible = false;
            }

            //calling method from Food subclass
            else if (cbCategory.SelectedItem.ToString() == "Food")
            {
                Expenses a = new Food();
                a.Account_ID = Global.global_account_ID;
                a.Month_Name = cbMonth.SelectedItem.ToString();
                exp = a.ViewExpense();
                datagridViewExp.DataSource = exp;
                datagridViewExp.Columns[1].Visible = false;
            }
        }

       //button to clear all fields 
        private void btnClear_Click(object sender, EventArgs e)
        {
            Expenses a = new All();
            a.Account_ID = Global.global_account_ID;
            cbCategory.SelectedItem = "All";
            //a.Account_ID = 7;
            exp = a.ViewExpense();
            datagridViewExp.DataSource = exp;
            datagridViewExp.Columns[1].Visible = false;
        }

       //button to delete an expense
        private void btnDel_Click(object sender, EventArgs e)
        {
            Expenses d = new All();
            d.Account_ID = Global.global_account_ID;
            d.Expense_ID = int.Parse(datagridViewExp.SelectedCells[0].Value.ToString());

            //validation for confirming delete
            string message = "Do you want to delete this expense";
            string title = "delete expense";
            MessageBoxButtons confirmbutton = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, confirmbutton);
            if (result == DialogResult.Yes)
            {
                d.DeleteExpense();
                MessageBox.Show("Expense deleted");
                cbCategory.SelectedItem = "All";
                d.Account_ID = 7;
                exp = d.ViewExpense();
                datagridViewExp.DataSource = exp;
                datagridViewExp.Columns[1].Visible = false;
            }
        }

        //button to enabling editing of an expense
        private void btnEditExp_Click(object sender, EventArgs e)
        {
            gpEdit.Visible = true;
            txtNewAmount.DataBindings.Clear();
            cbNewPT.DataBindings.Clear();
            cbNewCategory.DataBindings.Clear();
            cbNewMonth.DataBindings.Clear();
            txtNewDes.DataBindings.Clear();
            Expenses E = new All();
            E.Expense_ID = Convert.ToInt32(datagridViewExp.SelectedCells[0].Value.ToString());
            exp = E.GetExpense();
            txtNewAmount.DataBindings.Add("Text", exp, "Amount");
            cbNewPT.DataBindings.Add("Text", exp, "Payment_Type");
            cbNewCategory.DataBindings.Add("Text", exp, "Category");
            cbNewMonth.DataBindings.Add("Text", exp, "Month_Name");
            txtNewDes.DataBindings.Add("Text", exp, "Description");
        }

        //button for updating an expense
        private void btnUpdateExp_Click(object sender, EventArgs e)
        {
            Expenses u = new All();
            u.Account_ID = Global.global_account_ID;
            //u.Account_ID = 7;
            u.Expense_ID = int.Parse(datagridViewExp.SelectedCells[0].Value.ToString());
            u.Amount = Convert.ToInt32(txtNewAmount.Text);
            u.Payment_Type = cbNewPT.SelectedItem.ToString();
            u.Category = cbNewCategory.SelectedItem.ToString();
            u.Month_Name = cbNewMonth.SelectedItem.ToString();
            u.Description = txtNewDes.Text;

            //validation for confirming update
            string message = "Do you want to update this expense?";
            string title = "update expense";
            MessageBoxButtons confirmbutton = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, confirmbutton);
            if (result == DialogResult.Yes)
            {
                u.UpdateExpense();
                MessageBox.Show("Expense Updated");
                cbCategory.SelectedItem = "All";
                u.Account_ID = Global.global_account_ID;
                exp = u.ViewExpense();
                datagridViewExp.DataSource = exp;
                datagridViewExp.Columns[1].Visible = false;
            }
        }

        //redirecting user to Dashboard
        private void btnChart_Click(object sender, EventArgs e)
        {
            Dashboard obj2form;
            obj2form = new Dashboard();
            obj2form.Show();
   
        }

       //button for cancelling/disabling edit
        private void btnCancel_Click(object sender, EventArgs e)
        {
            gpEdit.Visible = false;
        }
    }
}
