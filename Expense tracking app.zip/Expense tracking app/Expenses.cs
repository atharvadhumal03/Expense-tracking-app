﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;

namespace bank_software
{
    abstract class Expenses
    {
        public int Expense_ID { get; set; }
        public int Account_ID { get; set; }
        public int Amount { get; set; }
        public string Payment_Type { get; set; }
        public string Category { get; set; }
        public string Month_Name { get; set; }
        public string Description { get; set; }

        abstract public void AddExpense();
        abstract public List<Expenses> ViewExpense();
        public List<Expenses> GetExpense()
        {
            List<Expenses> a = new List<Expenses>();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand select = new OleDbCommand();
            select.Connection = connection;
            select.CommandText = "SELECT Amount, Payment_Type, Category, Month_Name, Description FROM Expenses WHERE Expense_ID = ?";
            select.Parameters.AddWithValue("Expense_ID", this.Expense_ID);
            OleDbDataReader reader = select.ExecuteReader();
            while (reader.Read())
            {
                Expenses A = new All();
                A.Amount = (int)reader["Amount"];
                A.Payment_Type = (string)reader["Payment_Type"];
                A.Category = (string)reader["Category"];
                A.Month_Name = (string)reader["Month_Name"];
                A.Description = (string)reader["Description"];
                a.Add(A);
            }
            connection.Close();
            return a;
        }
        public void UpdateExpense()
        {
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand update = new OleDbCommand();
            update.Connection = connection;
            update.CommandText = "Update Expenses SET Amount=? ,Payment_Type=?, Category=?, Month_Name=?, Description=? WHERE Account_ID=? and Expense_ID=?";
            update.Parameters.AddWithValue("Amount", this.Amount);
            update.Parameters.AddWithValue("Payment_Type", this.Payment_Type);
            update.Parameters.AddWithValue("category", this.Category);
            update.Parameters.AddWithValue("Month_Name", this.Month_Name);
            update.Parameters.AddWithValue("Description", this.Description);
            update.Parameters.AddWithValue("Account_ID", this.Account_ID);
            update.Parameters.AddWithValue("Expense_ID", this.Expense_ID);
            update.ExecuteNonQuery();
            connection.Close();
        }
        public void DeleteExpense()
        {
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand delete = new OleDbCommand();
            delete.Connection = connection;
            delete.CommandText = "DELETE FROM Expenses WHERE Account_ID = ? AND Expense_ID=?";
            delete.Parameters.AddWithValue("Account_ID", this.Account_ID);
            delete.Parameters.AddWithValue("Expense_ID", this.Expense_ID);
            delete.ExecuteNonQuery();
            connection.Close();
        }
        public List<int> GetAmount()
        {
            List<int> TotalAmount = new List<int>();
            OleDbConnection connect;
            OleDbCommand get;
            connect = new OleDbConnection();
            connect.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connect.Open();
            get = new OleDbCommand();
            get.Connection = connect;
            get.CommandText = "SELECT Amount FROM Expenses WHERE Account_ID = ? and Month_Name=? and Category=?";
            get.Parameters.AddWithValue("Account_ID", this.Account_ID);
            get.Parameters.AddWithValue("Month_Name", this.Month_Name);
            get.Parameters.AddWithValue("Category", this.Category);
            OleDbDataReader reader = get.ExecuteReader();
            while (reader.Read())
            {
                int i = 0;
                i = (int)reader["Amount"];
                TotalAmount.Add(i);
            }
            connect.Close();
            return TotalAmount;
        }
    }
    class Home : Expenses
    {
        public override void AddExpense()
        {
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand insert = new OleDbCommand();
            insert.Connection = connection;
            insert.CommandText = "INSERT INTO Expenses (Account_ID, Amount, Payment_Type, Category, Month_Name, Description) Values (?,?,?,?,?,?)";
            insert.Parameters.AddWithValue("Account_ID", this.Account_ID);
            insert.Parameters.AddWithValue("Amount", this.Amount);
            insert.Parameters.AddWithValue("Payment_Type", this.Payment_Type);
            insert.Parameters.AddWithValue("Category", "Home");
            insert.Parameters.AddWithValue("Month_Name", this.Month_Name);
            insert.Parameters.AddWithValue("Description", this.Description);
            insert.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Expense Added");

        }
        public override List<Expenses> ViewExpense()
        {
            List<Expenses> a = new List<Expenses>();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand select = new OleDbCommand();
            select.Connection = connection;
            select.CommandText = "SELECT Expense_ID, Amount, Payment_Type, Category, Month_Name, Description FROM Expenses WHERE Account_ID = ? AND Month_Name = ? AND Category = ?";
            select.Parameters.AddWithValue("Account_ID", this.Account_ID);
            select.Parameters.AddWithValue("Month_Name", this.Month_Name);
            select.Parameters.AddWithValue("Category", "Home");
            OleDbDataReader reader = select.ExecuteReader();
            while (reader.Read())
            {
                Expenses A = new Home();
                A.Expense_ID = (int)reader["Expense_ID"];
                A.Amount = (int)reader["Amount"];
                A.Payment_Type = (string)reader["Payment_Type"];
                A.Category = (string)reader["Category"];
                A.Month_Name = (string)reader["Month_Name"];
                A.Description = (string)reader["Description"];
                a.Add(A);
            }
            connection.Close();
            return a;
        }
    }
    class Health : Expenses
    {
        public override void AddExpense()
        {
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand insert = new OleDbCommand();
            insert.Connection = connection;
            insert.CommandText = "INSERT INTO Expenses (Account_ID, Amount, Payment_Type, Category, Month_Name, Description) Values (?,?,?,?,?,?)";
            insert.Parameters.AddWithValue("Account_ID", this.Account_ID);
            insert.Parameters.AddWithValue("Amount", this.Amount);
            insert.Parameters.AddWithValue("Payment_Type", this.Payment_Type);
            insert.Parameters.AddWithValue("Category", "Health");
            insert.Parameters.AddWithValue("Month_Name", this.Month_Name);
            insert.Parameters.AddWithValue("Description", this.Description);
            insert.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Expense Added");

        }
        public override List<Expenses> ViewExpense()
        {
            List<Expenses> a = new List<Expenses>();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand select = new OleDbCommand();
            select.Connection = connection;
            select.CommandText = "SELECT Expense_ID, Amount, Payment_Type, Category, Month_Name, Description FROM Expenses WHERE Account_ID = ? AND Month_Name = ? AND Category = ?";
            select.Parameters.AddWithValue("Account_ID", this.Account_ID);
            select.Parameters.AddWithValue("Month_Name", this.Month_Name);
            select.Parameters.AddWithValue("Category", "Health");
            OleDbDataReader reader = select.ExecuteReader();
            while (reader.Read())
            {
                Expenses A = new Health();
                A.Expense_ID = (int)reader["Expense_ID"];
                A.Amount = (int)reader["Amount"];
                A.Payment_Type = (string)reader["Payment_Type"];
                A.Category = (string)reader["Category"];
                A.Month_Name = (string)reader["Month_Name"];
                A.Description = (string)reader["Description"];
                a.Add(A);
            }
            connection.Close();
            return a;
        }
    }
    class Transport : Expenses
    {
        public override void AddExpense()
        {
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand insert = new OleDbCommand();
            insert.Connection = connection;
            insert.CommandText = "INSERT INTO Expenses (Account_ID, Amount, Payment_Type, Category, Month_Name, Description) Values (?,?,?,?,?,?)";
            insert.Parameters.AddWithValue("Account_ID", this.Account_ID);
            insert.Parameters.AddWithValue("Amount", this.Amount);
            insert.Parameters.AddWithValue("Payment_Type", this.Payment_Type);
            insert.Parameters.AddWithValue("Category", "Transport");
            insert.Parameters.AddWithValue("Month_Name", this.Month_Name);
            insert.Parameters.AddWithValue("Description", this.Description);
            insert.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Expense Added");
        }
        public override List<Expenses> ViewExpense()
        {
            List<Expenses> a = new List<Expenses>();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand select = new OleDbCommand();
            select.Connection = connection;
            select.CommandText = "SELECT Expense_ID, Amount, Payment_Type, Category, Month_Name, Description FROM Expenses WHERE Account_ID = ? AND Month_Name = ? AND Category = ?";
            select.Parameters.AddWithValue("Account_ID", this.Account_ID);
            select.Parameters.AddWithValue("Month_Name", this.Month_Name);
            select.Parameters.AddWithValue("Category", "Transport");
            OleDbDataReader reader = select.ExecuteReader();
            while (reader.Read())
            {
                Expenses A = new Transport();
                A.Expense_ID = (int)reader["Expense_ID"];
                A.Amount = (int)reader["Amount"];
                A.Payment_Type = (string)reader["Payment_Type"];
                A.Category = (string)reader["Category"];
                A.Month_Name = (string)reader["Month_Name"];
                A.Description = (string)reader["Description"];
                a.Add(A);
            }
            connection.Close();
            return a;
        }
    }
    class Food : Expenses
    {
        public override void AddExpense()
        {
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand insert = new OleDbCommand();
            insert.Connection = connection;
            insert.CommandText = "INSERT INTO Expenses (Account_ID, Amount, Payment_Type, Category, Month_Name, Description) Values (?,?,?,?,?,?)";
            insert.Parameters.AddWithValue("Account_ID", this.Account_ID);
            insert.Parameters.AddWithValue("Amount", this.Amount);
            insert.Parameters.AddWithValue("Payment_Type", this.Payment_Type);
            insert.Parameters.AddWithValue("Category", "Food");
            insert.Parameters.AddWithValue("Month_Name", this.Month_Name);
            insert.Parameters.AddWithValue("Description", this.Description);
            insert.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Expense Added");
        }
        public override List<Expenses> ViewExpense()
        {
            List<Expenses> a = new List<Expenses>();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand select = new OleDbCommand();
            select.Connection = connection;
            select.CommandText = "SELECT Expense_ID, Amount, Payment_Type, Category, Month_Name, Description FROM Expenses WHERE Account_ID = ? AND Month_Name = ? OR Account_ID = ? Ae][poiuytrewq ND Category = ?";
            select.Parameters.AddWithValue("Account_ID", this.Account_ID);
            select.Parameters.AddWithValue("Month_Name", this.Month_Name);
            select.Parameters.AddWithValue("Category", "Food");
            OleDbDataReader reader = select.ExecuteReader();
            while (reader.Read())
            {
                Expenses A = new Food();
                A.Expense_ID = (int)reader["Expense_ID"];
                A.Amount = (int)reader["Amount"];
                A.Payment_Type = (string)reader["Payment_Type"];
                A.Category = (string)reader["Category"];
                A.Month_Name = (string)reader["Month_Name"];
                A.Description = (string)reader["Description"];
                a.Add(A);
            }
            connection.Close();
            return a;
        }


    }
    class All : Expenses
    {
        public override void AddExpense()
        {

        }
        public override List<Expenses> ViewExpense()
        {
            List<Expenses> a = new List<Expenses>();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand select = new OleDbCommand();
            select.Connection = connection;
            select.CommandText = "SELECT Expense_ID, Amount, Payment_Type, Category, Month_Name, Description FROM Expenses WHERE Account_ID = ?";
            select.Parameters.AddWithValue("Account_ID", this.Account_ID);
            OleDbDataReader reader = select.ExecuteReader();
            while (reader.Read())
            {
                Expenses A = new All();
                A.Expense_ID = (int)reader["Expense_ID"];
                A.Amount = (int)reader["Amount"];
                A.Payment_Type = (string)reader["Payment_Type"];
                A.Category = (string)reader["Category"];
                A.Month_Name = (string)reader["Month_Name"];
                A.Description = (string)reader["Description"];
                a.Add(A);
            }
            connection.Close();
            return a;
        }
    }
    class MonthlyExp : Expenses
    {
        public override void AddExpense()
        {

        }
        public override List<Expenses> ViewExpense()
        {
            List<Expenses> a = new List<Expenses>();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ExpenseTrackerDB.mdb";
            connection.Open();
            OleDbCommand select = new OleDbCommand();
            select.Connection = connection;
            select.CommandText = "SELECT Expense_ID, Amount, Payment_Type, Category, Month_Name, Description FROM Expenses WHERE Account_ID = ? AND Month_Name = ?";
            select.Parameters.AddWithValue("Account_ID", this.Account_ID);
            select.Parameters.AddWithValue("Month_Name", this.Month_Name);
            OleDbDataReader reader = select.ExecuteReader();
            while (reader.Read())
            {
                Expenses A = new MonthlyExp();
                A.Expense_ID = (int)reader["Expense_ID"];
                A.Amount = (int)reader["Amount"];
                A.Payment_Type = (string)reader["Payment_Type"];
                A.Category = (string)reader["Category"];
                A.Month_Name = (string)reader["Month_Name"];
                A.Description = (string)reader["Description"];
                a.Add(A);
            }
            connection.Close();
            return a;
        }
    }
    
}


