﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bank_software
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        //button to submit details for registration 
        private void btnregSubmit_Click(object sender, EventArgs e)
        {

            //boolean operators and other variables defined for validation
            bool upper = false;
            bool lower = false;
            bool contactno_len = false;
            bool pass_len = false;
            bool alphanumeric = true;
            string contact = txtContact.Text;
            string username = txtregUname.Text;
            string password = txtregCreatePass.Text;
            int contact_len = contact.Length;
            int username_len = username.Length;
            int password_len = password.Length;
            int x = 0;
            int i = 0;

            //validations implemented as per criteria given
            //validation for checking data entry in all fields
            if (txtregFname.Text == "" || txtregLname.Text == "" || txtregEmail.Text == "" || txtContact.Text == "" || txtregUname.Text == "" || txtregCreatePass.Text == "" || txtregPass.Text == "")
            {
                MessageBox.Show("Please enter all fields");
            }
            else
            {
                //validation for contact number 
                if (contact_len < 10)
                {
                    MessageBox.Show("Invalid contact number");
                }
                else
                {
                    contactno_len = true;
                }

                //validation for username containing no special chars
                while (alphanumeric == true)
                {
                    alphanumeric = char.IsLetterOrDigit(username, x);
                    x++;
                    if (x == username_len)
                    {
                        break;
                    }
                }
                if (alphanumeric == false)
                {
                    MessageBox.Show("Username cannot contain special characters");
                }
                else
                {
                    //validation for checking password contains atleast one upper case char
                    while (upper == false)
                    {
                        upper = char.IsUpper(password, i);
                        i++;
                        if (i == password_len)
                        {
                            break;
                        }
                    }
                    if (upper == false)
                    {
                        MessageBox.Show("Password must contain at least one upper character");
                    }
                    else
                    {
                        //validation for checking password must be at least 8 chars long
                        if (password_len < 8)
                        {
                            MessageBox.Show("Password must be at least 8 characters");
                        }
                        else
                        {

                            pass_len = true;

                            //validation for confirm password matching with created password
                            if (txtregCreatePass.Text == txtregPass.Text)
                            {
                                Account a = new Account();
                                a.First_Name = txtregFname.Text;
                                a.Last_Name = txtregLname.Text;
                                a.Email = txtregEmail.Text;
                                a.Contact_Number = txtContact.Text;
                                a.DOB = dateTimeDOB.Value;
                                a.Username = txtregUname.Text;
                                a.Password = txtregPass.Text;
                                a.AddAccount();
                            }
                            else
                            {
                                MessageBox.Show("Passwords do not match");
                            }
                        }

                    }

                }




            }



        }

        //button for resetting all fields
        private void btnregReset_Click(object sender, EventArgs e)
        {
            txtregFname.Text = "";
            txtregLname.Text = "";
            txtregEmail.Text = "";
            txtContact.Text = "";
            //dateTimeDOB.Value = default;
            txtregUname.Text = "";
            txtregCreatePass.Text = "";
            txtregPass.Text = "";
        }

        //button for redirecting user to login page 
        private void btnLoginPage_Click(object sender, EventArgs e)
        {
            Login obj2form;
            obj2form = new Login();
            obj2form.Show();
            this.Hide();
        }

        //button for redirecting user back to the home page
        private void pbBack_Click(object sender, EventArgs e)
        {
            HomePage obj1form;
            obj1form = new HomePage();
            obj1form.Show();
            this.Hide();
        }
    }
}