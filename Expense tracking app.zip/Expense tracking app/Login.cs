﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bank_software
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private void btnlogin_Click(object sender, EventArgs e)
        {
            Account account = new Account();
            account.Username = txtUsername.Text;
            account.Password = txtPassword.Text;
            bool result = account.AccountLogin();

            //validation for checking username and password have been entered
            if(txtUsername.Text == "" || txtPassword.Text == "")
            {
                MessageBox.Show("Please enter both fields");
            }
            else if (result == true)
            {
                Account a = account.FindAccountID();
                Global.global_account_ID = a.Account_ID;
                txtUsername.Text = "";
                txtPassword.Text = "";
                MessageBox.Show("Login Successful");
                Menu ob1form;
                ob1form = new Menu();
                ob1form.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Login Unsuccessful incorrect username or password");
            }
        }


        //button to clear all fields
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
        }

        //button redirecting to sign-up page
        private void btncreateacc_Click(object sender, EventArgs e)
        {
            Register obj2form;
            obj2form = new Register();
            obj2form.Show();
            this.Hide();
        }

        //back button taking user back to the home page
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            HomePage obj2form;
            obj2form = new HomePage();
            obj2form.Show();
            this.Hide();
        }
    }
}
