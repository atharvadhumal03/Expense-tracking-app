﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bank_software
{
    public partial class AddExp : Form
    {
        public AddExp()
        {
            InitializeComponent();
        }

       //redirecting user back to the menu page
        private void pbBack_Click(object sender, EventArgs e)
        {
            Menu ob1form;
            ob1form = new Menu();
            ob1form.Show();
            this.Hide();
        }

        private void btnAddExp_Click(object sender, EventArgs e)
        {
            Expenses h = new Home();
            Expenses h2 = new Health();
            Expenses t = new Transport();
            Expenses f = new Food();
            

            //validation for checking all fields have been entered
            if(txtAmount.Text == "" || cbPayment_Type.SelectedItem == null || cbCategory.SelectedItem == null ||cbMonth.SelectedItem == null)
            {
                MessageBox.Show("Please enter all fields");
            }
            
            //calling method from Home subclass
            else if (cbCategory.SelectedItem.ToString() == "Home")
            {
                h.Account_ID = Global.global_account_ID;
                h.Amount = Convert.ToInt32(txtAmount.Text);
                h.Payment_Type = cbPayment_Type.SelectedItem.ToString();
                h.Month_Name = cbMonth.SelectedItem.ToString();
                h.Description = txtDescription.Text;
                h.AddExpense();
                txtAmount.Text = "";
                cbPayment_Type.SelectedItem = default;
                cbCategory.SelectedItem = default;
                cbMonth.SelectedItem = default;
                txtDescription.Text = "";
            }

            //calling method from Health subclass
            else if (cbCategory.SelectedItem.ToString() == "Health")
            {
                h2.Account_ID = Global.global_account_ID;
                h2.Amount = Convert.ToInt32(txtAmount.Text);
                h2.Payment_Type = cbPayment_Type.SelectedItem.ToString();
                h2.Month_Name = cbMonth.SelectedItem.ToString();
                h2.Description = txtDescription.Text;
                h2.AddExpense();
                txtAmount.Text = "";
                cbPayment_Type.SelectedItem = default;
                cbCategory.SelectedItem = default;
                cbMonth.SelectedItem = default;
                txtDescription.Text = "";
            }

            //calling method from Transport subclass
            else if (cbCategory.SelectedItem.ToString() == "Transport")
            {
                t.Account_ID = Global.global_account_ID;
                t.Amount = Convert.ToInt32(txtAmount.Text);
                t.Payment_Type = cbPayment_Type.SelectedItem.ToString();
                t.Month_Name = cbMonth.SelectedItem.ToString();
                t.Description = txtDescription.Text;
                t.AddExpense();
                txtAmount.Text = "";
                cbPayment_Type.SelectedItem = default;
                cbCategory.SelectedItem = default;
                cbMonth.SelectedItem = default;
                txtDescription.Text = "";
            }

            //calling method from Food subclass
            else if (cbCategory.SelectedItem.ToString() == "Food")
            {
                f.Account_ID = Global.global_account_ID;
                f.Amount = Convert.ToInt32(txtAmount.Text);
                f.Payment_Type = cbPayment_Type.SelectedItem.ToString();
                f.Month_Name = cbMonth.SelectedItem.ToString();
                f.Description = txtDescription.Text;
                f.AddExpense();
                txtAmount.Text = "";
                cbPayment_Type.SelectedItem = default;
                cbCategory.SelectedItem = default;
                cbMonth.SelectedItem = default;
                txtDescription.Text = "";
            }
        }

      
        //button to reset all fields
        private void btnReset_Click(object sender, EventArgs e)
        {
            txtAmount.Text = "";
            cbPayment_Type.SelectedItem = default;
            cbCategory.SelectedItem = default;
            cbMonth.SelectedItem = default;
            txtDescription.Text = "";
        }
    }
}
