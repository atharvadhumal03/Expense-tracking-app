﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bank_software
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }
        List<Expenses> exp;

       //loading all the expense made by the user in chart visualization 
        private void Dashboard_Load(object sender, EventArgs e)
        {
            string[] months = new string[12] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            string[] category = new string[4] { "Home", "Health", "Food", "Transport" };
            chartDashBoard.ChartAreas[0].AxisX.Title = "MONTHS";
            chartDashBoard.ChartAreas[0].AxisY.Title = "AMOUNT";
            foreach (string m in months)
            {
                List<int> yvals = new List<int>();
                foreach (string c in category)
                {
                    Expenses g = new All();
                    g.Account_ID = Global.global_account_ID;
                    g.Month_Name = m;
                    g.Category = c;
                    yvals = g.GetAmount();
                    int total = 0;
                    if (yvals.Count == 0)
                    {
                        total = 0;
                    }
                    else
                    {
                        foreach (int y in yvals)
                        {
                            total = total + y;
                        }
                    }
                    chartDashBoard.Series[c].Points.AddXY(m, total);

                }
            }
            chartDashBoard.ChartAreas[0].AxisX.Interval = 1;
        }

        //back button redirecting user back to View Expenses page
        private void pbBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

    }
}
